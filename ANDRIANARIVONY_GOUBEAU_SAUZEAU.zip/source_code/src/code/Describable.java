package code;

public interface Describable {

	// Interface allowing display the description of place or game
	void readDescription();

}